import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'screens/auth_screen.dart';
import 'screens/setup_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/monitored_screen.dart';
import 'services/auth_service.dart';
import 'services/device_service.dart';
import 'services/session_service.dart';
import 'services/notification_service.dart';
import 'utils/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  await NotificationService.init();

  runApp(const RemoteMonitorApp());
}

class RemoteMonitorApp extends StatelessWidget {
  const RemoteMonitorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthService()),
        ChangeNotifierProvider(create: (_) => DeviceService()),
        ChangeNotifierProvider(create: (_) => SessionService()),
      ],
      child: MaterialApp(
        title: 'RemoteMonitor',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.dark(),
        home: const _AppRouter(),
      ),
    );
  }
}

class _AppRouter extends StatefulWidget {
  const _AppRouter();

  @override
  State<_AppRouter> createState() => _AppRouterState();
}

class _AppRouterState extends State<_AppRouter> {
  bool _loading = true;
  Widget _home = const SizedBox();

  @override
  void initState() {
    super.initState();
    _resolve();
  }

  Future<void> _resolve() async {
    final prefs = await SharedPreferences.getInstance();
    final setupDone = prefs.getBool('setup_complete') ?? false;
    final role = prefs.getString('device_role'); // 'controller' | 'monitored'

    // Restore auth
    final auth = context.read<AuthService>();
    await auth.restore();

    Widget home;
    if (!auth.isSignedIn) {
      home = const AuthScreen();
    } else if (!setupDone) {
      home = const SetupScreen();
    } else if (role == 'controller') {
      home = const DashboardScreen();
    } else {
      home = const MonitoredScreen();
    }

    if (mounted) setState(() { _home = home; _loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        backgroundColor: AppTheme.bgDark,
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(color: AppTheme.cyan),
              SizedBox(height: 16),
              Text('RemoteMonitor',
                  style: TextStyle(color: Colors.white38, fontSize: 13,
                      letterSpacing: 2)),
            ],
          ),
        ),
      );
    }
    return _home;
  }
}
