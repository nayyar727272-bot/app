class DeviceInfoModel {
  final String deviceId;
  final String deviceName;
  final String manufacturer;
  final String androidVersion;
  final int sdkVersion;
  final int batteryLevel;
  final bool isCharging;
  final bool isOnline;
  final String connectionType;
  final DateTime lastSeen;

  const DeviceInfoModel({
    required this.deviceId,
    required this.deviceName,
    required this.manufacturer,
    required this.androidVersion,
    required this.sdkVersion,
    required this.batteryLevel,
    required this.isCharging,
    required this.isOnline,
    required this.connectionType,
    required this.lastSeen,
  });

  Map<String, dynamic> toMap() => {
        'device_id': deviceId,
        'device_name': deviceName,
        'manufacturer': manufacturer,
        'android_version': androidVersion,
        'sdk_version': sdkVersion,
        'battery_level': batteryLevel,
        'is_charging': isCharging ? 1 : 0,
        'is_online': isOnline ? 1 : 0,
        'connection_type': connectionType,
        'last_seen': lastSeen.toIso8601String(),
      };

  factory DeviceInfoModel.fromMap(Map<String, dynamic> m) => DeviceInfoModel(
        deviceId: m['device_id'] as String? ?? '',
        deviceName: m['device_name'] as String? ?? 'Unknown',
        manufacturer: m['manufacturer'] as String? ?? '',
        androidVersion: m['android_version'] as String? ?? '',
        sdkVersion: m['sdk_version'] as int? ?? 0,
        batteryLevel: m['battery_level'] as int? ?? 0,
        isCharging: (m['is_charging'] as int? ?? 0) == 1,
        isOnline: (m['is_online'] as int? ?? 0) == 1,
        connectionType: m['connection_type'] as String? ?? 'Unknown',
        lastSeen: DateTime.tryParse(m['last_seen'] as String? ?? '') ??
            DateTime.now(),
      );
}
