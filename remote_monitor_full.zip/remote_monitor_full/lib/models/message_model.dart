enum MessageType { chat, file, command, system }

class MessageModel {
  final String id;
  final String sessionId;
  final String senderDeviceId;
  final MessageType type;
  final String content;
  final DateTime createdAt;

  const MessageModel({
    required this.id,
    required this.sessionId,
    required this.senderDeviceId,
    required this.type,
    required this.content,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'session_id': sessionId,
        'sender_device_id': senderDeviceId,
        'type': type.name,
        'content': content,
        'created_at': createdAt.toIso8601String(),
      };

  factory MessageModel.fromMap(Map<String, dynamic> m) => MessageModel(
        id: m['id'] as String,
        sessionId: m['session_id'] as String,
        senderDeviceId: m['sender_device_id'] as String,
        type: MessageType.values.firstWhere(
          (t) => t.name == m['type'],
          orElse: () => MessageType.chat,
        ),
        content: m['content'] as String,
        createdAt: DateTime.parse(m['created_at'] as String),
      );
}
