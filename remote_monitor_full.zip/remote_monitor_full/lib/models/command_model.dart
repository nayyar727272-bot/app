enum CommandType {
  back,
  home,
  recentApps,
  lock,
  vibrate,
  volumeUp,
  volumeDown,
  screenshot,
  tap,
}

class CommandModel {
  final String id;
  final String sessionId;
  final CommandType type;
  final Map<String, dynamic> params;
  final bool executed;
  final DateTime createdAt;

  const CommandModel({
    required this.id,
    required this.sessionId,
    required this.type,
    this.params = const {},
    this.executed = false,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'session_id': sessionId,
        'type': type.name,
        'params': params.toString(),
        'executed': executed ? 1 : 0,
        'created_at': createdAt.toIso8601String(),
      };

  factory CommandModel.fromMap(Map<String, dynamic> m) => CommandModel(
        id: m['id'] as String,
        sessionId: m['session_id'] as String,
        type: CommandType.values.firstWhere(
          (t) => t.name == m['type'],
          orElse: () => CommandType.back,
        ),
        params: const {},
        executed: (m['executed'] as int? ?? 0) == 1,
        createdAt: DateTime.parse(m['created_at'] as String),
      );
}
