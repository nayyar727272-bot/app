class UserModel {
  final String uid;
  final String email;
  final String role; // 'controller' | 'monitored'

  const UserModel({
    required this.uid,
    required this.email,
    required this.role,
  });

  Map<String, dynamic> toMap() =>
      {'uid': uid, 'email': email, 'role': role};

  factory UserModel.fromMap(Map<String, dynamic> m) => UserModel(
        uid: m['uid'] as String,
        email: m['email'] as String,
        role: m['role'] as String,
      );
}
