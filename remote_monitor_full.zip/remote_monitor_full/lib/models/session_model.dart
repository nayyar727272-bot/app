class SessionModel {
  final String id;
  final String pairingCode;
  final String controllerDeviceId;
  final String? monitoredDeviceId;
  final String status; // 'waiting' | 'active' | 'ended'
  final DateTime createdAt;

  const SessionModel({
    required this.id,
    required this.pairingCode,
    required this.controllerDeviceId,
    this.monitoredDeviceId,
    required this.status,
    required this.createdAt,
  });

  SessionModel copyWith({
    String? monitoredDeviceId,
    String? status,
  }) =>
      SessionModel(
        id: id,
        pairingCode: pairingCode,
        controllerDeviceId: controllerDeviceId,
        monitoredDeviceId: monitoredDeviceId ?? this.monitoredDeviceId,
        status: status ?? this.status,
        createdAt: createdAt,
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'pairing_code': pairingCode,
        'controller_device_id': controllerDeviceId,
        'monitored_device_id': monitoredDeviceId,
        'status': status,
        'created_at': createdAt.toIso8601String(),
      };

  factory SessionModel.fromMap(Map<String, dynamic> m) => SessionModel(
        id: m['id'] as String,
        pairingCode: m['pairing_code'] as String,
        controllerDeviceId: m['controller_device_id'] as String,
        monitoredDeviceId: m['monitored_device_id'] as String?,
        status: m['status'] as String,
        createdAt: DateTime.parse(m['created_at'] as String),
      );
}
