import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/command_model.dart';
import '../models/session_model.dart';
import '../services/auth_service.dart';
import '../services/device_service.dart';
import '../services/session_service.dart';
import '../services/notification_service.dart';
import '../utils/app_theme.dart';
import '../utils/extensions.dart';
import '../widgets/control_pad.dart';
import '../widgets/chat_panel.dart';
import '../widgets/device_info_panel.dart';
import '../widgets/file_panel.dart';
import 'auth_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabs;
  Timer? _pairPoller;
  bool _creating = false;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 4, vsync: this);
    context.read<DeviceService>().startCollecting();
    NotificationService.showOngoing(
        'RemoteMonitor', 'Controller session active');
  }

  @override
  void dispose() {
    _tabs.dispose();
    _pairPoller?.cancel();
    NotificationService.cancelOngoing();
    super.dispose();
  }

  Future<void> _createSession() async {
    setState(() => _creating = true);
    await context.read<SessionService>().createSession();
    setState(() => _creating = false);

    // Poll until monitored device joins (max 5 min)
    _pairPoller?.cancel();
    _pairPoller = Timer.periodic(const Duration(seconds: 3), (_) async {
      await context.read<SessionService>().checkIfPaired();
      if (context.read<SessionService>().isActive) {
        _pairPoller?.cancel();
        if (mounted) {
          NotificationService.show(
              'RemoteMonitor', 'Device connected!');
          context.showSnack('Device connected!');
        }
      }
    });
  }

  Future<void> _endSession() async {
    _pairPoller?.cancel();
    await context.read<SessionService>().endSession();
    if (mounted) context.showSnack('Session ended');
  }

  Future<void> _signOut() async {
    await context.read<SessionService>().endSession();
    await context.read<AuthService>().signOut();
    if (!mounted) return;
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (_) => const AuthScreen()));
  }

  @override
  Widget build(BuildContext context) {
    final session  = context.watch<SessionService>();
    final hasSession = session.session != null;

    return Scaffold(
      appBar: AppBar(
        title: const Text('DASHBOARD'),
        actions: [
          _StatusBadge(status: session.status),
          const SizedBox(width: 8),
          IconButton(
              icon: const Icon(Icons.logout),
              tooltip: 'Sign out',
              onPressed: _signOut),
        ],
        bottom: TabBar(
          controller: _tabs,
          tabs: const [
            Tab(text: 'CONTROLS'),
            Tab(text: 'DEVICE'),
            Tab(text: 'FILES'),
            Tab(text: 'CHAT'),
          ],
        ),
      ),
      body: Column(
        children: [
          // Session banner
          _SessionBanner(
            session: session.session,
            creating: _creating,
            onCreate: _createSession,
            onEnd: _endSession,
          ),
          Expanded(
            child: hasSession
                ? TabBarView(
                    controller: _tabs,
                    children: [
                      ControlPad(
                          onCommand: (type, params) => context
                              .read<SessionService>()
                              .sendCommand(type, params: params)),
                      const DeviceInfoPanel(),
                      const FilePanel(),
                      ChatPanel(
                        messages: session.messages,
                        onSend: (text) =>
                            context.read<SessionService>().sendMessage(text),
                      ),
                    ],
                  )
                : _NoSession(creating: _creating, onCreate: _createSession),
          ),
        ],
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final SessionStatus status;
  const _StatusBadge({required this.status});

  @override
  Widget build(BuildContext context) {
    final (label, color) = switch (status) {
      SessionStatus.active  => ('LIVE', AppTheme.green),
      SessionStatus.waiting => ('WAITING', AppTheme.amber),
      SessionStatus.ended   => ('ENDED', AppTheme.red),
      _                     => ('IDLE', AppTheme.textMuted),
    };
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 12),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.5)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Container(
            width: 6,
            height: 6,
            decoration:
                BoxDecoration(color: color, shape: BoxShape.circle)),
        const SizedBox(width: 6),
        Text(label,
            style: TextStyle(
                color: color,
                fontSize: 10,
                fontWeight: FontWeight.w700,
                letterSpacing: 1)),
      ]),
    );
  }
}

class _SessionBanner extends StatelessWidget {
  final SessionModel? session;
  final bool creating;
  final VoidCallback onCreate;
  final VoidCallback onEnd;

  const _SessionBanner({
    required this.session,
    required this.creating,
    required this.onCreate,
    required this.onEnd,
  });

  @override
  Widget build(BuildContext context) {
    if (session == null) return const SizedBox();
    return Container(
      color: AppTheme.bgCard,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(
        children: [
          const Icon(Icons.key, color: AppTheme.cyan, size: 16),
          const SizedBox(width: 8),
          Text('Code: ', style: AppTheme.label),
          Text(
            session!.pairingCode,
            style: AppTheme.mono.copyWith(
                fontSize: 18,
                letterSpacing: 4,
                fontWeight: FontWeight.w700,
                color: AppTheme.cyan),
          ),
          const Spacer(),
          TextButton(
            onPressed: onEnd,
            style: TextButton.styleFrom(
                foregroundColor: AppTheme.red,
                padding: const EdgeInsets.symmetric(horizontal: 10)),
            child: const Text('END', style: TextStyle(fontSize: 12)),
          ),
        ],
      ),
    );
  }
}

class _NoSession extends StatelessWidget {
  final bool creating;
  final VoidCallback onCreate;

  const _NoSession({required this.creating, required this.onCreate});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.link_off, size: 56, color: AppTheme.textMuted),
            const SizedBox(height: 16),
            Text('No Active Session', style: AppTheme.subheading),
            const SizedBox(height: 8),
            const Text(
              'Start a session to monitor and control another device.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppTheme.textMuted, height: 1.5),
            ),
            const SizedBox(height: 28),
            ElevatedButton.icon(
              onPressed: creating ? null : onCreate,
              icon: creating
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: AppTheme.bgDark))
                  : const Icon(Icons.add, size: 18),
              label:
                  Text(creating ? 'CREATING…' : 'START SESSION'),
            ),
          ],
        ),
      ),
    );
  }
}
