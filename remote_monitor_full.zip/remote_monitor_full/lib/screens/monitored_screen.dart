import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/command_model.dart';
import '../services/auth_service.dart';
import '../services/device_service.dart';
import '../services/session_service.dart';
import '../services/accessibility_bridge.dart';
import '../services/notification_service.dart';
import '../utils/app_theme.dart';
import '../utils/device_id.dart';
import '../utils/extensions.dart';
import '../widgets/chat_panel.dart';
import 'auth_screen.dart';

class MonitoredScreen extends StatefulWidget {
  const MonitoredScreen({super.key});

  @override
  State<MonitoredScreen> createState() => _MonitoredScreenState();
}

class _MonitoredScreenState extends State<MonitoredScreen>
    with SingleTickerProviderStateMixin {
  final _codeCtrl = TextEditingController();
  late TabController _tabs;
  bool _joining = false;
  String? _joinError;
  String _deviceId = '';

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this);
    context.read<DeviceService>().startCollecting();
    _loadId();
  }

  Future<void> _loadId() async {
    final id = await DeviceId.get();
    if (mounted) setState(() => _deviceId = id);
  }

  Future<void> _join() async {
    final code = _codeCtrl.text.trim();
    if (code.length != 6) {
      setState(() => _joinError = 'Enter the 6-digit code from the controller.');
      return;
    }
    setState(() { _joining = true; _joinError = null; });

    final err = await context.read<SessionService>().joinSession(code);
    if (!mounted) return;
    setState(() => _joining = false);

    if (err != null) {
      setState(() => _joinError = err);
      return;
    }

    NotificationService.showOngoing(
        'RemoteMonitor', 'Monitoring session active. Tap to open.');
    context.showSnack('Session joined. Monitoring active.');
    _listenForCommands();
  }

  void _listenForCommands() {
    // Poll via SessionService (already polling)
    // Execute each pending command via AccessibilityBridge
    Timer.periodic(const Duration(seconds: 3), (timer) async {
      final svc = context.read<SessionService>();
      if (!svc.isActive) { timer.cancel(); return; }

      for (final cmd in svc.pending) {
        final err = await AccessibilityBridge.execute(cmd);
        if (err != null) {
          debugPrint('[MonitoredScreen] command error: $err');
        }
        await svc.markExecuted(cmd.id);
      }
    });
  }

  Future<void> _disconnect() async {
    await context.read<SessionService>().endSession();
    NotificationService.cancelOngoing();
    if (mounted) {
      setState(() {});
      context.showSnack('Session ended');
    }
  }

  Future<void> _signOut() async {
    await context.read<SessionService>().endSession();
    NotificationService.cancelOngoing();
    await context.read<AuthService>().signOut();
    if (!mounted) return;
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (_) => const AuthScreen()));
  }

  @override
  void dispose() {
    _codeCtrl.dispose();
    _tabs.dispose();
    NotificationService.cancelOngoing();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionService>();
    final connected = session.isActive;

    return Scaffold(
      appBar: AppBar(
        title: const Text('MONITORED DEVICE'),
        actions: [
          IconButton(
              icon: const Icon(Icons.logout),
              tooltip: 'Sign out',
              onPressed: _signOut),
        ],
        bottom: connected
            ? TabBar(
                controller: _tabs,
                tabs: const [
                  Tab(text: 'STATUS'),
                  Tab(text: 'CHAT'),
                ],
              )
            : null,
      ),
      body: connected
          ? TabBarView(
              controller: _tabs,
              children: [
                _connectedStatus(session),
                ChatPanel(
                  messages: session.messages,
                  onSend: (t) =>
                      context.read<SessionService>().sendMessage(t),
                ),
              ],
            )
          : _joinView(),
    );
  }

  Widget _joinView() {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Device ID card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: AppTheme.bgCard,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('YOUR DEVICE ID', style: AppTheme.label),
                  const SizedBox(height: 8),
                  SelectableText(
                    _deviceId.isEmpty ? '…' : _deviceId,
                    style: AppTheme.mono.copyWith(
                        fontSize: 17,
                        letterSpacing: 2,
                        fontWeight: FontWeight.w700),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            Text('Join Session', style: AppTheme.heading),
            const SizedBox(height: 8),
            const Text(
              'Enter the 6-digit pairing code shown on the controller device.',
              style: TextStyle(color: AppTheme.textMuted, height: 1.5),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _codeCtrl,
              keyboardType: TextInputType.number,
              maxLength: 6,
              textAlign: TextAlign.center,
              style: AppTheme.mono.copyWith(
                  fontSize: 28,
                  letterSpacing: 8,
                  fontWeight: FontWeight.w700),
              decoration: const InputDecoration(
                hintText: '000000',
                counterText: '',
              ),
            ),
            if (_joinError != null) ...[
              const SizedBox(height: 10),
              Text(_joinError!,
                  style: const TextStyle(
                      color: AppTheme.red, fontSize: 13)),
            ],
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _joining ? null : _join,
              child: _joining
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: AppTheme.bgDark))
                  : const Text('JOIN SESSION'),
            ),
            const SizedBox(height: 32),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppTheme.bgCard,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppTheme.border),
              ),
              child: const Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.shield_outlined,
                      color: AppTheme.cyan, size: 16),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'By joining you consent to screen monitoring and '
                      'remote control for the session duration. '
                      'A notification will always be visible while active.',
                      style: TextStyle(
                          color: AppTheme.textMuted,
                          fontSize: 12,
                          height: 1.6),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _connectedStatus(SessionService session) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppTheme.green.withOpacity(0.07),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                  color: AppTheme.green.withOpacity(0.3)),
            ),
            child: Column(
              children: [
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Container(
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                          color: AppTheme.green, shape: BoxShape.circle)),
                  const SizedBox(width: 8),
                  const Text('SESSION ACTIVE',
                      style: TextStyle(
                          color: AppTheme.green,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.2,
                          fontSize: 12)),
                ]),
                const SizedBox(height: 14),
                Text(
                  'Code: ${session.session?.pairingCode ?? "—"}',
                  style: AppTheme.mono
                      .copyWith(letterSpacing: 3, fontSize: 14),
                ),
                const SizedBox(height: 6),
                const Text(
                  'Screen monitoring and remote control are active.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: AppTheme.textMuted, fontSize: 12),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          _deviceService(),
          const Spacer(),
          OutlinedButton(
            style: OutlinedButton.styleFrom(
              foregroundColor: AppTheme.red,
              side: const BorderSide(color: AppTheme.red),
              minimumSize: const Size.fromHeight(48),
            ),
            onPressed: _disconnect,
            child: const Text('END SESSION & DISCONNECT'),
          ),
        ],
      ),
    );
  }

  Widget _deviceService() {
    final info = context.watch<DeviceService>().info;
    if (info == null) return const SizedBox();
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        children: [
          _Row('Device', info.deviceName),
          const Divider(height: 16),
          _Row('Battery', '${info.batteryLevel}%${info.isCharging ? " ⚡" : ""}'),
          const Divider(height: 16),
          _Row('Connection', info.connectionType),
          const Divider(height: 16),
          _Row('Android', info.androidVersion),
        ],
      ),
    );
  }
}

class _Row extends StatelessWidget {
  final String label, value;
  const _Row(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(label, style: AppTheme.label),
        const Spacer(),
        Text(value,
            style: const TextStyle(
                color: AppTheme.textPri, fontSize: 13)),
      ],
    );
  }
}
