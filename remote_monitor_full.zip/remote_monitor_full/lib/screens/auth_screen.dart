import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/auth_service.dart';
import '../utils/app_theme.dart';
import '../utils/extensions.dart';
import 'setup_screen.dart';
import 'dashboard_screen.dart';
import 'monitored_screen.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _email    = TextEditingController();
  final _password = TextEditingController();
  final _form     = GlobalKey<FormState>();
  bool _isLogin   = true;
  bool _loading   = false;
  bool _obscure   = true;
  String _role    = 'controller';

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!(_form.currentState?.validate() ?? false)) return;
    setState(() => _loading = true);

    final auth = context.read<AuthService>();
    String? err;

    if (_isLogin) {
      err = await auth.signIn(
          email: _email.text, password: _password.text);
    } else {
      err = await auth.signUp(
          email: _email.text, password: _password.text, role: _role);
    }

    if (!mounted) return;
    setState(() => _loading = false);

    if (err != null) {
      context.showSnack(err, error: true);
      return;
    }

    // Navigate based on role & setup status
    final prefs = await SharedPreferences.getInstance();
    final setupDone = prefs.getBool('setup_complete') ?? false;

    if (!mounted) return;
    if (!setupDone) {
      _go(const SetupScreen());
    } else if (auth.user?.role == 'controller') {
      _go(const DashboardScreen());
    } else {
      _go(const MonitoredScreen());
    }
  }

  void _go(Widget screen) {
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(28),
            child: Form(
              key: _form,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Logo
                  Center(
                    child: Container(
                      width: 72, height: 72,
                      decoration: BoxDecoration(
                        color: AppTheme.cyan.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                            color: AppTheme.cyan.withOpacity(0.35)),
                      ),
                      child: const Icon(Icons.monitor_heart_outlined,
                          color: AppTheme.cyan, size: 36),
                    ),
                  ),
                  const SizedBox(height: 24),
                  Center(
                    child: Text('RemoteMonitor', style: AppTheme.heading),
                  ),
                  const SizedBox(height: 6),
                  Center(
                    child: Text(
                      _isLogin
                          ? 'Sign in to continue'
                          : 'Create a new account',
                      style: const TextStyle(
                          color: AppTheme.textMuted, fontSize: 13),
                    ),
                  ),
                  const SizedBox(height: 32),

                  // Email
                  TextFormField(
                    controller: _email,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(
                      labelText: 'Email',
                      prefixIcon:
                          Icon(Icons.email_outlined, size: 18),
                    ),
                    validator: (v) {
                      if (v == null || v.trim().isEmpty) {
                        return 'Email is required';
                      }
                      if (!v.contains('@')) return 'Enter a valid email';
                      return null;
                    },
                  ),
                  const SizedBox(height: 12),

                  // Password
                  TextFormField(
                    controller: _password,
                    obscureText: _obscure,
                    decoration: InputDecoration(
                      labelText: 'Password',
                      prefixIcon:
                          const Icon(Icons.lock_outline, size: 18),
                      suffixIcon: IconButton(
                        icon: Icon(
                          _obscure
                              ? Icons.visibility_off_outlined
                              : Icons.visibility_outlined,
                          size: 18,
                          color: AppTheme.textMuted,
                        ),
                        onPressed: () =>
                            setState(() => _obscure = !_obscure),
                      ),
                    ),
                    validator: (v) {
                      if (v == null || v.isEmpty) {
                        return 'Password is required';
                      }
                      if (!_isLogin && v.length < 6) {
                        return 'At least 6 characters';
                      }
                      return null;
                    },
                  ),

                  // Role picker (sign-up only)
                  if (!_isLogin) ...[
                    const SizedBox(height: 16),
                    Text('I want to…', style: AppTheme.label),
                    const SizedBox(height: 8),
                    _RolePicker(
                      value: _role,
                      onChanged: (r) => setState(() => _role = r),
                    ),
                  ],

                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: _loading ? null : _submit,
                    child: _loading
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: AppTheme.bgDark),
                          )
                        : Text(_isLogin ? 'SIGN IN' : 'CREATE ACCOUNT'),
                  ),

                  const SizedBox(height: 14),
                  TextButton(
                    onPressed: () =>
                        setState(() => _isLogin = !_isLogin),
                    child: Text(
                      _isLogin
                          ? "Don't have an account? Sign Up"
                          : 'Already have an account? Sign In',
                      style: const TextStyle(
                          color: AppTheme.cyan, fontSize: 13),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _RolePicker extends StatelessWidget {
  final String value;
  final ValueChanged<String> onChanged;

  const _RolePicker({required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
            child: _Chip(
          label: 'Control devices',
          icon: Icons.dashboard_outlined,
          selected: value == 'controller',
          onTap: () => onChanged('controller'),
        )),
        const SizedBox(width: 10),
        Expanded(
            child: _Chip(
          label: 'Be monitored',
          icon: Icons.phone_android,
          selected: value == 'monitored',
          onTap: () => onChanged('monitored'),
        )),
      ],
    );
  }
}

class _Chip extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const _Chip(
      {required this.label,
      required this.icon,
      required this.selected,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    final color = selected ? AppTheme.cyan : AppTheme.textMuted;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
        decoration: BoxDecoration(
          color: selected
              ? AppTheme.cyan.withOpacity(0.08)
              : AppTheme.bgElev,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
              color: selected ? AppTheme.cyan : AppTheme.border),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(height: 6),
            Text(label,
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: color,
                    fontSize: 11,
                    fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}
