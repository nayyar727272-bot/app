import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../utils/app_theme.dart';
import '../utils/device_id.dart';
import '../utils/extensions.dart';
import 'dashboard_screen.dart';
import 'monitored_screen.dart';

class SetupScreen extends StatefulWidget {
  const SetupScreen({super.key});

  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  int _step = 0;
  String _deviceId = '';

  // permission states: null=unchecked, true=granted, false=denied
  final Map<String, bool?> _perms = {
    'Notifications': null,
    'Storage': null,
  };
  bool _accessibilityHintShown = false;

  @override
  void initState() {
    super.initState();
    _checkPerms();
    _loadDeviceId();
  }

  Future<void> _loadDeviceId() async {
    final id = await DeviceId.get();
    if (mounted) setState(() => _deviceId = id);
  }

  Future<void> _checkPerms() async {
    final notif = await Permission.notification.isGranted;
    bool storage = false;
    try {
      storage = await Permission.storage.isGranted;
    } catch (_) {}
    if (mounted) {
      setState(() {
        _perms['Notifications'] = notif;
        _perms['Storage'] = storage;
      });
    }
  }

  Future<void> _requestPerm(String name) async {
    PermissionStatus status;
    switch (name) {
      case 'Notifications':
        status = await Permission.notification.request();
      case 'Storage':
        try {
          status = await Permission.storage.request();
        } catch (_) {
          status = PermissionStatus.granted;
        }
      default:
        return;
    }
    if (mounted) setState(() => _perms[name] = status.isGranted);
  }

  Future<void> _finish() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('setup_complete', true);
    if (!mounted) return;
    Navigator.pushReplacement(
        context,
        MaterialPageRoute(
            builder: (_) => prefs.getString('device_role') == 'monitored'
                ? const MonitoredScreen()
                : const DashboardScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('SETUP')),
      body: SafeArea(
        child: Column(
          children: [
            _StepBar(current: _step, total: 3),
            Expanded(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 250),
                child: _body(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _body() {
    return switch (_step) {
      0 => _welcome(),
      1 => _permissions(),
      _ => _deviceIdStep(),
    };
  }

  Widget _welcome() {
    return SingleChildScrollView(
      key: const ValueKey(0),
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 12),
          Text('Welcome to\nRemoteMonitor', style: AppTheme.heading),
          const SizedBox(height: 12),
          const Text(
            'This app lets you monitor and control another device '
            'with full transparency and consent.\n\n'
            'Both devices must agree to the session. '
            'You can disconnect at any time.',
            style: TextStyle(
                color: AppTheme.textMuted, height: 1.6, fontSize: 14),
          ),
          const SizedBox(height: 28),
          _infoBox(
            icon: Icons.shield_outlined,
            color: AppTheme.green,
            text:
                'All sessions require explicit consent from the monitored device.',
          ),
          const SizedBox(height: 10),
          _infoBox(
            icon: Icons.notifications_active_outlined,
            color: AppTheme.cyan,
            text:
                'A persistent notification is shown while monitoring is active.',
          ),
          const SizedBox(height: 32),
          ElevatedButton(
            onPressed: () => setState(() => _step = 1),
            child: const Text('GET STARTED'),
          ),
        ],
      ),
    );
  }

  Widget _permissions() {
    final allGranted = _perms.values.every((v) => v == true);
    return SingleChildScrollView(
      key: const ValueKey(1),
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Permissions', style: AppTheme.heading),
          const SizedBox(height: 8),
          const Text(
            'Grant the following permissions so the app can function correctly.',
            style:
                TextStyle(color: AppTheme.textMuted, height: 1.5),
          ),
          const SizedBox(height: 24),
          ..._perms.entries.map(
            (e) => _PermTile(
              name: e.key,
              granted: e.value,
              onGrant: () => _requestPerm(e.key),
            ),
          ),
          const SizedBox(height: 16),
          // Accessibility note
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppTheme.amber.withOpacity(0.07),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                  color: AppTheme.amber.withOpacity(0.3)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  const Icon(Icons.info_outline,
                      color: AppTheme.amber, size: 16),
                  const SizedBox(width: 8),
                  Text('Accessibility Service (Monitored only)',
                      style: AppTheme.label
                          .copyWith(color: AppTheme.amber)),
                ]),
                const SizedBox(height: 8),
                const Text(
                  'If this is the monitored device, go to:\n'
                  'Settings → Accessibility → Installed Services → RemoteMonitor → Enable\n\n'
                  'This cannot be granted automatically — Android requires manual user action.',
                  style: TextStyle(
                      color: AppTheme.textMuted,
                      fontSize: 12,
                      height: 1.6),
                ),
                const SizedBox(height: 8),
                TextButton(
                  style: TextButton.styleFrom(
                      padding: EdgeInsets.zero,
                      minimumSize: const Size(0, 32)),
                  onPressed: () => openAppSettings(),
                  child: const Text('Open Accessibility Settings →',
                      style: TextStyle(
                          color: AppTheme.amber, fontSize: 12)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 28),
          ElevatedButton(
            onPressed: () => setState(() => _step = 2),
            child: Text(allGranted ? 'CONTINUE' : 'CONTINUE ANYWAY'),
          ),
        ],
      ),
    );
  }

  Widget _deviceIdStep() {
    return Padding(
      key: const ValueKey(2),
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Your Device ID', style: AppTheme.heading),
          const SizedBox(height: 8),
          const Text(
            'This unique ID identifies your device in a session. '
            'Share it with the controller to pair.',
            style: TextStyle(
                color: AppTheme.textMuted, height: 1.5),
          ),
          const SizedBox(height: 28),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: AppTheme.bgCard,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                  color: AppTheme.cyan.withOpacity(0.3)),
            ),
            child: Column(
              children: [
                const Icon(Icons.fingerprint,
                    color: AppTheme.cyan, size: 44),
                const SizedBox(height: 16),
                SelectableText(
                  _deviceId.isEmpty ? '…' : _deviceId,
                  style: AppTheme.mono.copyWith(
                    fontSize: 20,
                    letterSpacing: 3,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 6),
                Text('DEVICE IDENTIFIER', style: AppTheme.label),
              ],
            ),
          ),
          const Spacer(),
          ElevatedButton(
            onPressed: _finish,
            child: const Text('FINISH SETUP'),
          ),
        ],
      ),
    );
  }

  Widget _infoBox(
      {required IconData icon,
      required Color color,
      required String text}) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withOpacity(0.07),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 10),
          Expanded(
              child: Text(text,
                  style: TextStyle(
                      color: color.withOpacity(0.9),
                      fontSize: 13,
                      height: 1.5))),
        ],
      ),
    );
  }
}

class _StepBar extends StatelessWidget {
  final int current, total;
  const _StepBar({required this.current, required this.total});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Row(
        children: List.generate(
          total,
          (i) => Expanded(
            child: Container(
              height: 3,
              margin: EdgeInsets.only(right: i < total - 1 ? 4 : 0),
              decoration: BoxDecoration(
                color: i <= current
                    ? AppTheme.cyan
                    : AppTheme.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _PermTile extends StatelessWidget {
  final String name;
  final bool? granted;
  final VoidCallback onGrant;

  const _PermTile(
      {required this.name, required this.granted, required this.onGrant});

  @override
  Widget build(BuildContext context) {
    final ok = granted == true;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
            color: ok ? AppTheme.green.withOpacity(0.3) : AppTheme.border),
      ),
      child: Row(
        children: [
          Icon(
            ok
                ? Icons.check_circle_outline
                : Icons.radio_button_unchecked,
            color: ok ? AppTheme.green : AppTheme.textMuted,
            size: 20,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(name,
                style: const TextStyle(
                    fontSize: 14, fontWeight: FontWeight.w500)),
          ),
          if (!ok)
            TextButton(
              onPressed: onGrant,
              child: const Text('Grant',
                  style: TextStyle(color: AppTheme.cyan, fontSize: 12)),
            )
          else
            const Text('Granted',
                style: TextStyle(
                    color: AppTheme.green,
                    fontSize: 12,
                    fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
