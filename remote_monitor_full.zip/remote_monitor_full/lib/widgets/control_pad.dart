import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/command_model.dart';
import '../utils/app_theme.dart';

class ControlPad extends StatelessWidget {
  final Future<void> Function(CommandType type, Map<String, dynamic> params)
      onCommand;

  const ControlPad({super.key, required this.onCommand});

  void _tap(BuildContext context, CommandType type,
      {Map<String, dynamic> params = const {}}) {
    HapticFeedback.lightImpact();
    onCommand(type, params).catchError((_) {});
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('NAVIGATION', style: AppTheme.label),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _Btn(
                  icon: Icons.arrow_back,
                  label: 'Back',
                  color: AppTheme.textMuted,
                  onTap: () => _tap(context, CommandType.back),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _Btn(
                  icon: Icons.circle_outlined,
                  label: 'Home',
                  color: AppTheme.textMuted,
                  onTap: () => _tap(context, CommandType.home),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _Btn(
                  icon: Icons.view_agenda_outlined,
                  label: 'Recent',
                  color: AppTheme.textMuted,
                  onTap: () => _tap(context, CommandType.recentApps),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Text('ACTIONS', style: AppTheme.label),
          const SizedBox(height: 10),
          GridView.count(
            crossAxisCount: 3,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1.3,
            children: [
              _Btn(
                icon: Icons.lock_outline,
                label: 'Lock',
                color: AppTheme.amber,
                onTap: () => _tap(context, CommandType.lock),
              ),
              _Btn(
                icon: Icons.vibration,
                label: 'Vibrate',
                color: AppTheme.cyan,
                onTap: () => _tap(context, CommandType.vibrate),
              ),
              _Btn(
                icon: Icons.screenshot_monitor_outlined,
                label: 'Screenshot',
                color: AppTheme.cyan,
                onTap: () => _tap(context, CommandType.screenshot),
              ),
              _Btn(
                icon: Icons.volume_up_outlined,
                label: 'Vol +',
                color: AppTheme.green,
                onTap: () => _tap(context, CommandType.volumeUp),
              ),
              _Btn(
                icon: Icons.volume_down_outlined,
                label: 'Vol -',
                color: AppTheme.green,
                onTap: () => _tap(context, CommandType.volumeDown),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppTheme.bgCard,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppTheme.border),
            ),
            child: const Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.info_outline,
                    color: AppTheme.textMuted, size: 15),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Commands are queued and executed by the monitored '
                    'device when its Accessibility Service is active.',
                    style: TextStyle(
                        color: AppTheme.textMuted,
                        fontSize: 12,
                        height: 1.5),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Btn extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _Btn({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: color.withOpacity(0.07),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 24),
            const SizedBox(height: 6),
            Text(label,
                style: TextStyle(
                    color: color,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.5)),
          ],
        ),
      ),
    );
  }
}
