import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/message_model.dart';
import '../services/auth_service.dart';
import '../utils/app_theme.dart';
import '../utils/extensions.dart';

class ChatPanel extends StatefulWidget {
  final List<MessageModel> messages;
  final Future<void> Function(String text) onSend;

  const ChatPanel({
    super.key,
    required this.messages,
    required this.onSend,
  });

  @override
  State<ChatPanel> createState() => _ChatPanelState();
}

class _ChatPanelState extends State<ChatPanel> {
  final _ctrl   = TextEditingController();
  final _scroll = ScrollController();
  bool _sending = false;

  @override
  void didUpdateWidget(ChatPanel old) {
    super.didUpdateWidget(old);
    if (widget.messages.length != old.messages.length) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _scrollBottom());
    }
  }

  void _scrollBottom() {
    if (_scroll.hasClients) {
      _scroll.animateTo(
        _scroll.position.maxScrollExtent,
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOut,
      );
    }
  }

  Future<void> _send() async {
    final text = _ctrl.text.trim();
    if (text.isEmpty || _sending) return;
    _ctrl.clear();
    setState(() => _sending = true);
    await widget.onSend(text);
    if (mounted) setState(() => _sending = false);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final myUid = context.read<AuthService>().currentUid;

    return Column(
      children: [
        Expanded(
          child: widget.messages.isEmpty
              ? const Center(
                  child: Text('No messages yet.',
                      style: TextStyle(color: AppTheme.textMuted)))
              : ListView.builder(
                  controller: _scroll,
                  padding: const EdgeInsets.all(12),
                  itemCount: widget.messages.length,
                  itemBuilder: (_, i) {
                    final m = widget.messages[i];
                    // We identify "mine" by senderDeviceId vs uid
                    // For simplicity, show right-aligned if sender matches uid
                    final isMe = m.senderDeviceId == myUid ||
                        m.senderDeviceId.isEmpty;
                    return _Bubble(
                        text: m.content,
                        isMe: isMe,
                        time: m.createdAt.timeLabel);
                  },
                ),
        ),
        Container(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
          decoration: const BoxDecoration(
            color: AppTheme.bgCard,
            border: Border(top: BorderSide(color: AppTheme.border)),
          ),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _ctrl,
                  minLines: 1,
                  maxLines: 4,
                  decoration: const InputDecoration(
                    hintText: 'Type a message…',
                    isDense: true,
                  ),
                  onSubmitted: (_) => _send(),
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: _sending ? null : _send,
                child: Container(
                  padding: const EdgeInsets.all(11),
                  decoration: BoxDecoration(
                    color: _sending
                        ? AppTheme.textMuted
                        : AppTheme.cyan,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(Icons.send,
                      color: AppTheme.bgDark, size: 18),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _Bubble extends StatelessWidget {
  final String text, time;
  final bool isMe;

  const _Bubble(
      {required this.text, required this.isMe, required this.time});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints: BoxConstraints(
            maxWidth: MediaQuery.of(context).size.width * 0.72),
        margin: const EdgeInsets.symmetric(vertical: 3),
        padding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: isMe
              ? AppTheme.cyan.withOpacity(0.14)
              : AppTheme.bgCard,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(14),
            topRight: const Radius.circular(14),
            bottomLeft:
                Radius.circular(isMe ? 14 : 4),
            bottomRight:
                Radius.circular(isMe ? 4 : 14),
          ),
          border: Border.all(
            color: isMe
                ? AppTheme.cyan.withOpacity(0.25)
                : AppTheme.border,
          ),
        ),
        child: Column(
          crossAxisAlignment: isMe
              ? CrossAxisAlignment.end
              : CrossAxisAlignment.start,
          children: [
            Text(text,
                style: const TextStyle(
                    color: AppTheme.textPri,
                    fontSize: 14,
                    height: 1.4)),
            const SizedBox(height: 4),
            Text(time,
                style: const TextStyle(
                    color: AppTheme.textMuted, fontSize: 10)),
          ],
        ),
      ),
    );
  }
}
