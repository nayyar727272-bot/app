import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/device_service.dart';
import '../utils/app_theme.dart';
import '../utils/extensions.dart';

class DeviceInfoPanel extends StatelessWidget {
  const DeviceInfoPanel({super.key});

  @override
  Widget build(BuildContext context) {
    final info = context.watch<DeviceService>().info;

    if (info == null) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(color: AppTheme.cyan),
            SizedBox(height: 12),
            Text('Collecting device info…',
                style: TextStyle(color: AppTheme.textMuted)),
          ],
        ),
      );
    }

    final battColor = info.batteryLevel > 50
        ? AppTheme.green
        : info.batteryLevel > 20
            ? AppTheme.amber
            : AppTheme.red;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Status row
          Row(children: [
            _Dot(info.isOnline),
            const SizedBox(width: 8),
            Text(info.isOnline ? 'ONLINE' : 'OFFLINE',
                style: TextStyle(
                    color: info.isOnline ? AppTheme.green : AppTheme.red,
                    fontWeight: FontWeight.w700,
                    fontSize: 12,
                    letterSpacing: 1.2)),
            const Spacer(),
            Text('Last seen: ${info.lastSeen.ago}',
                style: const TextStyle(
                    color: AppTheme.textMuted, fontSize: 11)),
          ]),
          const SizedBox(height: 16),

          // Battery card
          _Card(children: [
            Row(children: [
              Icon(
                info.isCharging
                    ? Icons.battery_charging_full
                    : Icons.battery_std,
                color: battColor,
                size: 20,
              ),
              const SizedBox(width: 8),
              Text('Battery',
                  style: AppTheme.label.copyWith(color: battColor)),
              const Spacer(),
              Text('${info.batteryLevel}%',
                  style: TextStyle(
                      color: battColor, fontWeight: FontWeight.w700)),
            ]),
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: info.batteryLevel / 100,
                backgroundColor: AppTheme.border,
                color: battColor,
                minHeight: 7,
              ),
            ),
            if (info.isCharging) ...[
              const SizedBox(height: 6),
              Text('Charging',
                  style: TextStyle(color: battColor, fontSize: 11)),
            ],
          ]),
          const SizedBox(height: 10),

          // Device info cards
          _InfoRow('Device', info.deviceName),
          _InfoRow('Manufacturer', info.manufacturer),
          _InfoRow('Android', '${info.androidVersion} (SDK ${info.sdkVersion})'),
          _InfoRow('Connection', info.connectionType),
          _InfoRow('Device ID', info.deviceId, mono: true),
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label, value;
  final bool mono;
  const _InfoRow(this.label, this.value, {this.mono = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.border),
      ),
      child: Row(
        children: [
          Text(label, style: AppTheme.label),
          const Spacer(),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: TextStyle(
                color: AppTheme.textPri,
                fontSize: 13,
                fontFamily: mono ? 'JetBrainsMono' : null,
                letterSpacing: mono ? 1 : null,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Card extends StatelessWidget {
  final List<Widget> children;
  const _Card({required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: children),
    );
  }
}

class _Dot extends StatelessWidget {
  final bool online;
  const _Dot(this.online);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 9,
      height: 9,
      decoration: BoxDecoration(
        color: online ? AppTheme.green : AppTheme.red,
        shape: BoxShape.circle,
      ),
    );
  }
}
