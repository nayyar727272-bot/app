import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:provider/provider.dart';

import '../models/message_model.dart';
import '../services/session_service.dart';
import '../services/auth_service.dart';
import '../utils/app_theme.dart';
import '../utils/extensions.dart';

/// Displays the list of transferred files for the active session and allows
/// the controller to pick and "send" a file (stored locally; in a real
/// deployment this would upload to a server or transfer over WebSocket).
class FilePanel extends StatefulWidget {
  const FilePanel({super.key});

  @override
  State<FilePanel> createState() => _FilePanelState();
}

class _FilePanelState extends State<FilePanel> {
  bool _picking = false;

  Future<void> _pickAndSend() async {
    setState(() => _picking = true);
    try {
      final result = await FilePicker.platform.pickFiles(
        allowMultiple: false,
        withData: false,
      );
      if (result == null || result.files.isEmpty) return;

      final file = result.files.first;
      final name = file.name;
      final size = file.size;

      // Record the file transfer as a message in the session
      await context.read<SessionService>().sendMessage(
            '📎 FILE: $name (${size.readableSize})',
          );

      if (mounted) context.showSnack('File queued: $name');
    } catch (e) {
      if (mounted) context.showSnack('Failed to pick file: $e', error: true);
    } finally {
      if (mounted) setState(() => _picking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final session  = context.watch<SessionService>();
    final fileMessages = session.messages
        .where((m) => m.content.startsWith('📎 FILE:'))
        .toList();

    return Column(
      children: [
        // Send button
        Padding(
          padding: const EdgeInsets.all(16),
          child: ElevatedButton.icon(
            onPressed: _picking ? null : _pickAndSend,
            icon: _picking
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: AppTheme.bgDark))
                : const Icon(Icons.upload_file, size: 18),
            label: Text(_picking ? 'PICKING…' : 'SEND FILE'),
          ),
        ),

        const Divider(height: 1),

        // File list
        Expanded(
          child: fileMessages.isEmpty
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.folder_open,
                          size: 48, color: AppTheme.textMuted),
                      const SizedBox(height: 12),
                      const Text('No files transferred yet.',
                          style:
                              TextStyle(color: AppTheme.textMuted)),
                    ],
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.all(12),
                  itemCount: fileMessages.length,
                  separatorBuilder: (_, __) =>
                      const SizedBox(height: 8),
                  itemBuilder: (_, i) {
                    final msg = fileMessages[i];
                    // Parse "📎 FILE: name.ext (3.2MB)"
                    final content = msg.content
                        .replaceFirst('📎 FILE: ', '');
                    final parts = content.split(' (');
                    final name = parts.first;
                    final size =
                        parts.length > 1 ? parts[1].replaceAll(')', '') : '';
                    final myUid =
                        context.read<AuthService>().currentUid;
                    final isMe = msg.senderDeviceId == myUid ||
                        msg.senderDeviceId.isEmpty;

                    return _FileTile(
                      name: name,
                      size: size,
                      isMine: isMe,
                      sentAt: msg.createdAt,
                    );
                  },
                ),
        ),
      ],
    );
  }
}

class _FileTile extends StatelessWidget {
  final String name;
  final String size;
  final bool isMine;
  final DateTime sentAt;

  const _FileTile({
    required this.name,
    required this.size,
    required this.isMine,
    required this.sentAt,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.border),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppTheme.cyan.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.insert_drive_file_outlined,
                color: AppTheme.cyan, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name,
                    style: const TextStyle(
                        fontWeight: FontWeight.w500,
                        fontSize: 13),
                    overflow: TextOverflow.ellipsis),
                const SizedBox(height: 3),
                Text(
                  '$size  •  ${isMine ? "Sent" : "Received"}  •  ${sentAt.timeLabel}',
                  style: const TextStyle(
                      color: AppTheme.textMuted, fontSize: 11),
                ),
              ],
            ),
          ),
          Icon(
            isMine ? Icons.check_circle_outline : Icons.download_outlined,
            color: isMine ? AppTheme.green : AppTheme.cyan,
            size: 18,
          ),
        ],
      ),
    );
  }
}
