import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;

import '../models/session_model.dart';
import '../models/message_model.dart';
import '../models/command_model.dart';
import '../models/device_info_model.dart';

class DbService {
  static Database? _db;

  static Future<Database> get db async {
    _db ??= await _open();
    return _db!;
  }

  static Future<Database> _open() async {
    final dbPath = await getDatabasesPath();
    final path = p.join(dbPath, 'remote_monitor.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: (db, _) async {
        await db.execute('''
          CREATE TABLE sessions(
            id TEXT PRIMARY KEY,
            pairing_code TEXT NOT NULL,
            controller_device_id TEXT NOT NULL,
            monitored_device_id TEXT,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE messages(
            id TEXT PRIMARY KEY,
            session_id TEXT NOT NULL,
            sender_device_id TEXT NOT NULL,
            type TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE commands(
            id TEXT PRIMARY KEY,
            session_id TEXT NOT NULL,
            type TEXT NOT NULL,
            params TEXT,
            executed INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE device_info(
            device_id TEXT PRIMARY KEY,
            device_name TEXT,
            manufacturer TEXT,
            android_version TEXT,
            sdk_version INTEGER,
            battery_level INTEGER,
            is_charging INTEGER,
            is_online INTEGER,
            connection_type TEXT,
            last_seen TEXT
          )
        ''');
      },
    );
  }

  // ── Sessions ──────────────────────────────────────────────
  static Future<void> upsertSession(SessionModel s) async {
    final d = await db;
    await d.insert('sessions', s.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  static Future<SessionModel?> getSession(String id) async {
    final d = await db;
    final rows = await d.query('sessions', where: 'id = ?', whereArgs: [id]);
    if (rows.isEmpty) return null;
    return SessionModel.fromMap(rows.first);
  }

  static Future<List<SessionModel>> allSessions() async {
    final d = await db;
    final rows = await d.query('sessions', orderBy: 'created_at DESC');
    return rows.map(SessionModel.fromMap).toList();
  }

  // ── Messages ──────────────────────────────────────────────
  static Future<void> insertMessage(MessageModel m) async {
    final d = await db;
    await d.insert('messages', m.toMap(),
        conflictAlgorithm: ConflictAlgorithm.ignore);
  }

  static Future<List<MessageModel>> messagesFor(String sessionId) async {
    final d = await db;
    final rows = await d.query('messages',
        where: 'session_id = ?',
        whereArgs: [sessionId],
        orderBy: 'created_at ASC');
    return rows.map(MessageModel.fromMap).toList();
  }

  // ── Commands ──────────────────────────────────────────────
  static Future<void> insertCommand(CommandModel c) async {
    final d = await db;
    await d.insert('commands', c.toMap(),
        conflictAlgorithm: ConflictAlgorithm.ignore);
  }

  static Future<List<CommandModel>> pendingCommands(String sessionId) async {
    final d = await db;
    final rows = await d.query('commands',
        where: 'session_id = ? AND executed = 0',
        whereArgs: [sessionId],
        orderBy: 'created_at ASC');
    return rows.map(CommandModel.fromMap).toList();
  }

  static Future<void> markCommandExecuted(String id) async {
    final d = await db;
    await d.update('commands', {'executed': 1},
        where: 'id = ?', whereArgs: [id]);
  }

  // ── Device info ───────────────────────────────────────────
  static Future<void> upsertDeviceInfo(DeviceInfoModel info) async {
    final d = await db;
    await d.insert('device_info', info.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  static Future<DeviceInfoModel?> getDeviceInfo(String deviceId) async {
    final d = await db;
    final rows = await d.query('device_info',
        where: 'device_id = ?', whereArgs: [deviceId]);
    if (rows.isEmpty) return null;
    return DeviceInfoModel.fromMap(rows.first);
  }
}
