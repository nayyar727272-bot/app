import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

import '../models/user_model.dart';

class AuthService extends ChangeNotifier {
  static const _usersKey  = 'users_db';
  static const _activeKey = 'active_user';

  UserModel? _user;

  UserModel? get user    => _user;
  bool get isSignedIn    => _user != null;
  String get currentUid  => _user?.uid ?? '';

  // ── Restore session on startup ────────────────────────────
  Future<void> restore() async {
    final prefs = await SharedPreferences.getInstance();
    final json  = prefs.getString(_activeKey);
    if (json != null) {
      _user = UserModel.fromMap(jsonDecode(json) as Map<String, dynamic>);
      notifyListeners();
    }
  }

  // ── Sign up ───────────────────────────────────────────────
  Future<String?> signUp(
      {required String email, required String password, required String role}) async {
    final prefs = await SharedPreferences.getInstance();
    final usersJson = prefs.getString(_usersKey);
    final Map<String, dynamic> users =
        usersJson != null ? jsonDecode(usersJson) as Map<String, dynamic> : {};

    if (users.containsKey(email.trim().toLowerCase())) {
      return 'An account with this email already exists.';
    }
    if (password.length < 6) {
      return 'Password must be at least 6 characters.';
    }

    final uid = const Uuid().v4();
    final hashed = _hash(password);
    final u = UserModel(uid: uid, email: email.trim().toLowerCase(), role: role);
    users[u.email] = {...u.toMap(), 'password': hashed};

    await prefs.setString(_usersKey, jsonEncode(users));
    await _persist(prefs, u);
    _user = u;
    notifyListeners();
    return null;
  }

  // ── Sign in ───────────────────────────────────────────────
  Future<String?> signIn(
      {required String email, required String password}) async {
    final prefs   = await SharedPreferences.getInstance();
    final usersJson = prefs.getString(_usersKey);
    if (usersJson == null) return 'No account found. Please sign up first.';

    final users = jsonDecode(usersJson) as Map<String, dynamic>;
    final key   = email.trim().toLowerCase();
    if (!users.containsKey(key)) return 'No account found with this email.';

    final stored = users[key] as Map<String, dynamic>;
    if (stored['password'] != _hash(password)) return 'Incorrect password.';

    final u = UserModel.fromMap(stored);
    await _persist(prefs, u);
    _user = u;
    notifyListeners();
    return null;
  }

  // ── Sign out ──────────────────────────────────────────────
  Future<void> signOut() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_activeKey);
    _user = null;
    notifyListeners();
  }

  // ── Helpers ───────────────────────────────────────────────
  Future<void> _persist(SharedPreferences prefs, UserModel u) async =>
      prefs.setString(_activeKey, jsonEncode(u.toMap()));

  String _hash(String password) =>
      sha256.convert(utf8.encode(password)).toString();
}
