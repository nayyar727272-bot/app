import 'dart:async';
import 'package:battery_plus/battery_plus.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';

import '../models/device_info_model.dart';
import '../services/db_service.dart';
import '../utils/device_id.dart';

class DeviceService extends ChangeNotifier {
  final _battery      = Battery();
  final _connectivity = Connectivity();
  final _deviceInfo   = DeviceInfoPlugin();

  DeviceInfoModel? _info;
  Timer? _timer;

  DeviceInfoModel? get info => _info;

  Future<void> startCollecting() async {
    await _collect();
    _timer = Timer.periodic(const Duration(seconds: 15), (_) => _collect());
  }

  void stop() {
    _timer?.cancel();
    _timer = null;
  }

  Future<void> _collect() async {
    try {
      final batteryLevel  = await _battery.batteryLevel;
      final batteryState  = await _battery.batteryState;
      final connectivity  = await _connectivity.checkConnectivity();
      final android       = await _deviceInfo.androidInfo;
      final id            = await DeviceId.get();

      _info = DeviceInfoModel(
        deviceId:       id,
        deviceName:     android.model,
        manufacturer:   android.manufacturer,
        androidVersion: android.version.release,
        sdkVersion:     android.version.sdkInt,
        batteryLevel:   batteryLevel,
        isCharging:     batteryState == BatteryState.charging,
        isOnline:       connectivity != ConnectivityResult.none,
        connectionType: connectivity == ConnectivityResult.wifi ? 'WiFi' : 'Mobile',
        lastSeen:       DateTime.now(),
      );

      await DbService.upsertDeviceInfo(_info!);
      notifyListeners();
    } catch (e) {
      debugPrint('[DeviceService] collect error: $e');
    }
  }

  @override
  void dispose() {
    stop();
    super.dispose();
  }
}
