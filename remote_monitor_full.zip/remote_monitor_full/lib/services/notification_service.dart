import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  static final _plugin = FlutterLocalNotificationsPlugin();
  static bool _ready   = false;

  static const _androidChannel = AndroidNotificationDetails(
    'rm_channel',
    'RemoteMonitor',
    channelDescription: 'Session & alert notifications',
    importance: Importance.high,
    priority:   Priority.high,
    playSound:  false,
  );

  static Future<void> init() async {
    const settings = InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
    );
    await _plugin.initialize(settings);
    _ready = true;
  }

  static Future<void> show(String title, String body) async {
    if (!_ready) return;
    await _plugin.show(
      DateTime.now().millisecondsSinceEpoch ~/ 1000 % 100000,
      title,
      body,
      const NotificationDetails(android: _androidChannel),
    );
  }

  static Future<void> showOngoing(String title, String body) async {
    if (!_ready) return;
    const details = AndroidNotificationDetails(
      'rm_service',
      'RemoteMonitor Service',
      channelDescription: 'Background service notification',
      importance:   Importance.low,
      priority:     Priority.low,
      ongoing:      true,
      showWhen:     false,
      playSound:    false,
    );
    await _plugin.show(
      9999,
      title,
      body,
      const NotificationDetails(android: details),
    );
  }

  static Future<void> cancelOngoing() async {
    if (!_ready) return;
    await _plugin.cancel(9999);
  }
}
