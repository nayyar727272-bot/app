import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../models/session_model.dart';
import '../models/message_model.dart';
import '../models/command_model.dart';
import '../services/db_service.dart';
import '../utils/device_id.dart';

enum SessionStatus { idle, waiting, active, ended }

class SessionService extends ChangeNotifier {
  SessionModel? _session;
  List<MessageModel> _messages = [];
  List<CommandModel> _pendingCommands = [];
  SessionStatus _status = SessionStatus.idle;
  Timer? _pollTimer;

  SessionModel? get session         => _session;
  List<MessageModel> get messages   => List.unmodifiable(_messages);
  List<CommandModel> get pending    => List.unmodifiable(_pendingCommands);
  SessionStatus get status          => _status;
  bool get isActive                 => _status == SessionStatus.active;
  String? get sessionId             => _session?.id;

  // ── Controller: create session ────────────────────────────
  Future<SessionModel> createSession() async {
    final id       = const Uuid().v4();
    final code     = await _uniqueCode();
    final deviceId = await DeviceId.get();

    final s = SessionModel(
      id:                 id,
      pairingCode:        code,
      controllerDeviceId: deviceId,
      status:             'waiting',
      createdAt:          DateTime.now(),
    );
    await DbService.upsertSession(s);
    _session = s;
    _status  = SessionStatus.waiting;
    notifyListeners();
    return s;
  }

  // ── Monitored: join by pairing code ──────────────────────
  Future<String?> joinSession(String code) async {
    final all = await DbService.allSessions();
    final match = all.where((s) => s.pairingCode == code.trim()).firstOrNull;
    if (match == null) return 'Session not found. Check the code and try again.';
    if (match.status == 'ended') return 'This session has already ended.';

    final deviceId = await DeviceId.get();
    final updated  = match.copyWith(
      monitoredDeviceId: deviceId,
      status: 'active',
    );
    await DbService.upsertSession(updated);
    _session = updated;
    _status  = SessionStatus.active;
    _startPolling();
    notifyListeners();
    return null; // success
  }

  // ── Controller: mark session active once monitored joins ──
  Future<void> checkIfPaired() async {
    if (_session == null) return;
    final fresh = await DbService.getSession(_session!.id);
    if (fresh != null && fresh.status == 'active') {
      _session = fresh;
      _status  = SessionStatus.active;
      _startPolling();
      notifyListeners();
    }
  }

  // ── End session ───────────────────────────────────────────
  Future<void> endSession() async {
    if (_session == null) return;
    final ended = _session!.copyWith(status: 'ended');
    await DbService.upsertSession(ended);
    _session = ended;
    _status  = SessionStatus.ended;
    _stopPolling();
    notifyListeners();
  }

  // ── Messages ──────────────────────────────────────────────
  Future<void> sendMessage(String text) async {
    if (_session == null) return;
    final deviceId = await DeviceId.get();
    final m = MessageModel(
      id:             const Uuid().v4(),
      sessionId:      _session!.id,
      senderDeviceId: deviceId,
      type:           MessageType.chat,
      content:        text,
      createdAt:      DateTime.now(),
    );
    await DbService.insertMessage(m);
    _messages = await DbService.messagesFor(_session!.id);
    notifyListeners();
  }

  Future<void> _refreshMessages() async {
    if (_session == null) return;
    _messages = await DbService.messagesFor(_session!.id);
    notifyListeners();
  }

  // ── Commands ──────────────────────────────────────────────
  Future<void> sendCommand(CommandType type,
      {Map<String, dynamic> params = const {}}) async {
    if (_session == null) return;
    final c = CommandModel(
      id:        const Uuid().v4(),
      sessionId: _session!.id,
      type:      type,
      params:    params,
      createdAt: DateTime.now(),
    );
    await DbService.insertCommand(c);
    notifyListeners();
  }

  Future<void> refreshPendingCommands() async {
    if (_session == null) return;
    _pendingCommands = await DbService.pendingCommands(_session!.id);
    notifyListeners();
  }

  Future<void> markExecuted(String commandId) async {
    await DbService.markCommandExecuted(commandId);
    await refreshPendingCommands();
  }

  // ── Polling (simulates real-time sync) ───────────────────
  void _startPolling() {
    _pollTimer = Timer.periodic(const Duration(seconds: 3), (_) async {
      await _refreshMessages();
      await refreshPendingCommands();
    });
  }

  void _stopPolling() {
    _pollTimer?.cancel();
    _pollTimer = null;
  }

  Future<String> _uniqueCode() async {
    // Generate a code not already used
    for (var i = 0; i < 10; i++) {
      final code = DeviceId.pairingCode();
      final sessions = await DbService.allSessions();
      if (!sessions.any((s) => s.pairingCode == code)) return code;
    }
    return DeviceId.pairingCode();
  }

  @override
  void dispose() {
    _stopPolling();
    super.dispose();
  }
}
