import 'package:flutter/services.dart';
import '../models/command_model.dart';

/// Calls into the native Kotlin AccessibilityService via MethodChannel.
/// If the service is not enabled, returns an error string.
class AccessibilityBridge {
  static const _channel =
      MethodChannel('com.remotemonitor/accessibility');

  static Future<String?> execute(CommandModel cmd) async {
    try {
      final method = cmd.type.name; // matches Kotlin when-branch names
      await _channel.invokeMethod<void>(method, cmd.params);
      return null; // success
    } on PlatformException catch (e) {
      return e.message ?? 'Unknown native error';
    } catch (e) {
      return e.toString();
    }
  }

  static Future<bool> isEnabled() async {
    try {
      final result =
          await _channel.invokeMethod<bool>('isAccessibilityEnabled');
      return result ?? false;
    } catch (_) {
      return false;
    }
  }
}
