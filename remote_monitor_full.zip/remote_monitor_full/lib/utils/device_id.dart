import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

class DeviceId {
  static const _key = 'device_id';

  /// Returns stored ID or generates and stores a new one.
  static Future<String> get() async {
    final prefs = await SharedPreferences.getInstance();
    final stored = prefs.getString(_key);
    if (stored != null && stored.isNotEmpty) return stored;

    final id = await _generate();
    await prefs.setString(_key, id);
    return id;
  }

  static Future<String> _generate() async {
    try {
      final plugin = DeviceInfoPlugin();
      final info = await plugin.androidInfo;
      final seed =
          '${info.id}_${info.model}_${info.hardware}_${info.fingerprint}';
      final digest = sha256.convert(utf8.encode(seed)).toString().toUpperCase();
      final raw = digest.substring(0, 16);
      return '${raw.substring(0, 4)}-${raw.substring(4, 8)}'
          '-${raw.substring(8, 12)}-${raw.substring(12, 16)}';
    } catch (_) {
      // Fallback: random UUID truncated
      final uuid = const Uuid().v4().replaceAll('-', '').toUpperCase();
      return '${uuid.substring(0, 4)}-${uuid.substring(4, 8)}'
          '-${uuid.substring(8, 12)}-${uuid.substring(12, 16)}';
    }
  }

  /// Short numeric pairing code (6 digits).
  static String pairingCode() {
    final bytes = utf8.encode(DateTime.now().millisecondsSinceEpoch.toString());
    final hash = sha256.convert(bytes).toString();
    final num = int.parse(hash.substring(0, 8), radix: 16) % 900000 + 100000;
    return num.toString();
  }
}
