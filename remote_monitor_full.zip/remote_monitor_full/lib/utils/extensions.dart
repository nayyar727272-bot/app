import 'package:flutter/material.dart';
import 'app_theme.dart';

extension ContextX on BuildContext {
  void showSnack(String msg, {bool error = false}) {
    ScaffoldMessenger.of(this).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: error ? AppTheme.red : AppTheme.bgElev,
    ));
  }
}

extension DateX on DateTime {
  String get timeLabel {
    final h = hour.toString().padLeft(2, '0');
    final m = minute.toString().padLeft(2, '0');
    return '$h:$m';
  }

  String get ago {
    final diff = DateTime.now().difference(this);
    if (diff.inSeconds < 30) return 'just now';
    if (diff.inMinutes < 1) return '${diff.inSeconds}s ago';
    if (diff.inHours < 1) return '${diff.inMinutes}m ago';
    return '${diff.inHours}h ago';
  }
}

extension IntBytes on int {
  String get readableSize {
    if (this < 1024) return '${this}B';
    if (this < 1024 * 1024) return '${(this / 1024).toStringAsFixed(1)}KB';
    return '${(this / (1024 * 1024)).toStringAsFixed(1)}MB';
  }
}
