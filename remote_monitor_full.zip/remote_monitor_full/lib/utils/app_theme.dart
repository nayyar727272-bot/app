import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static const Color bgDark     = Color(0xFF080C14);
  static const Color bgCard     = Color(0xFF101720);
  static const Color bgElev     = Color(0xFF1A2333);
  static const Color cyan       = Color(0xFF00E5FF);
  static const Color green      = Color(0xFF00E676);
  static const Color red        = Color(0xFFFF1744);
  static const Color amber      = Color(0xFFFFAB00);
  static const Color textPri    = Color(0xFFE8EDF2);
  static const Color textMuted  = Color(0xFF4A5568);
  static const Color border     = Color(0xFF1E293B);

  static ThemeData dark() {
    final base = ThemeData.dark(useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: bgDark,
      colorScheme: const ColorScheme.dark(
        primary:   cyan,
        secondary: green,
        surface:   bgCard,
        error:     red,
      ),
      textTheme: GoogleFonts.spaceGroteskTextTheme(base.textTheme)
          .apply(bodyColor: textPri, displayColor: textPri),
      appBarTheme: AppBarTheme(
        backgroundColor: bgDark,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        titleTextStyle: GoogleFonts.jetBrainsMono(
          color: textPri, fontSize: 14,
          fontWeight: FontWeight.w600, letterSpacing: 1.5,
        ),
        iconTheme: const IconThemeData(color: textPri, size: 20),
        actionsIconTheme: const IconThemeData(color: textPri, size: 20),
      ),
      cardTheme: CardTheme(
        color: bgCard, elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: border),
        ),
        margin: EdgeInsets.zero,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: cyan, foregroundColor: bgDark,
          minimumSize: const Size.fromHeight(48),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          textStyle: GoogleFonts.jetBrainsMono(
              fontWeight: FontWeight.w700, letterSpacing: 1),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: textPri,
          minimumSize: const Size.fromHeight(48),
          side: const BorderSide(color: border),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: bgElev,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: border)),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: border)),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: cyan, width: 1.5)),
        errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: red)),
        labelStyle: const TextStyle(color: textMuted),
        hintStyle: const TextStyle(color: textMuted),
      ),
      dividerTheme:
          const DividerThemeData(color: border, thickness: 1, space: 1),
      tabBarTheme: TabBarTheme(
        indicatorColor: cyan,
        labelColor: cyan,
        unselectedLabelColor: textMuted,
        indicatorSize: TabBarIndicatorSize.tab,
        labelStyle: GoogleFonts.jetBrainsMono(
            fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.2),
        unselectedLabelStyle: GoogleFonts.jetBrainsMono(
            fontSize: 11, fontWeight: FontWeight.w600),
      ),
      snackBarTheme: const SnackBarThemeData(
        backgroundColor: bgElev,
        contentTextStyle: TextStyle(color: textPri),
      ),
    );
  }

  // Convenience text styles
  static TextStyle get mono => GoogleFonts.jetBrainsMono(
      color: textPri, fontSize: 13);
  static TextStyle get label => GoogleFonts.spaceGrotesk(
      color: textMuted, fontSize: 11,
      letterSpacing: 1.5, fontWeight: FontWeight.w600);
  static TextStyle get heading => GoogleFonts.spaceGrotesk(
      color: textPri, fontSize: 22, fontWeight: FontWeight.w700);
  static TextStyle get subheading => GoogleFonts.spaceGrotesk(
      color: textPri, fontSize: 15, fontWeight: FontWeight.w600);
}
