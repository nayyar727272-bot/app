package com.remotemonitor

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * MainActivity
 *
 * Hosts the Flutter engine and exposes a MethodChannel so Dart code can:
 *   1. Execute accessibility actions via [RemoteAccessibilityService]
 *   2. Check whether the Accessibility Service is enabled
 *   3. Start / stop the foreground [RemoteMonitorService]
 *
 * Channel name must match [AccessibilityBridge.CHANNEL] on the Dart side.
 */
class MainActivity : FlutterActivity() {

    companion object {
        const val ACCESSIBILITY_CHANNEL = "com.remotemonitor/accessibility"
        const val SERVICE_CHANNEL       = "com.remotemonitor/service"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        // ── Accessibility MethodChannel ────────────────────────
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, ACCESSIBILITY_CHANNEL)
            .setMethodCallHandler { call, result ->
                val svc = RemoteAccessibilityService.instance

                when (call.method) {

                    // ── Query ──────────────────────────────────
                    "isAccessibilityEnabled" -> {
                        result.success(isAccessibilityServiceEnabled())
                    }

                    "openAccessibilitySettings" -> {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        result.success(null)
                    }

                    // ── Navigation ─────────────────────────────
                    "back" -> {
                        if (svc == null) { result.error("NO_SVC", notEnabledMsg(), null); return@setMethodCallHandler }
                        svc.performBack()
                        result.success(null)
                    }

                    "home" -> {
                        if (svc == null) { result.error("NO_SVC", notEnabledMsg(), null); return@setMethodCallHandler }
                        svc.performHome()
                        result.success(null)
                    }

                    "recentApps" -> {
                        if (svc == null) { result.error("NO_SVC", notEnabledMsg(), null); return@setMethodCallHandler }
                        svc.performRecentApps()
                        result.success(null)
                    }

                    // ── Actions ────────────────────────────────
                    "lock" -> {
                        if (svc == null) { result.error("NO_SVC", notEnabledMsg(), null); return@setMethodCallHandler }
                        svc.performLock()
                        result.success(null)
                    }

                    "vibrate" -> {
                        if (svc == null) { result.error("NO_SVC", notEnabledMsg(), null); return@setMethodCallHandler }
                        svc.performVibrate()
                        result.success(null)
                    }

                    "volumeUp" -> {
                        if (svc == null) { result.error("NO_SVC", notEnabledMsg(), null); return@setMethodCallHandler }
                        svc.performVolumeUp(applicationContext)
                        result.success(null)
                    }

                    "volumeDown" -> {
                        if (svc == null) { result.error("NO_SVC", notEnabledMsg(), null); return@setMethodCallHandler }
                        svc.performVolumeDown(applicationContext)
                        result.success(null)
                    }

                    "screenshot" -> {
                        if (svc == null) { result.error("NO_SVC", notEnabledMsg(), null); return@setMethodCallHandler }
                        svc.performScreenshot()
                        result.success(null)
                    }

                    "tap" -> {
                        if (svc == null) { result.error("NO_SVC", notEnabledMsg(), null); return@setMethodCallHandler }
                        val x = (call.argument<Any>("x") as? Number)?.toFloat() ?: 0f
                        val y = (call.argument<Any>("y") as? Number)?.toFloat() ?: 0f
                        svc.performTap(x, y)
                        result.success(null)
                    }

                    else -> result.notImplemented()
                }
            }

        // ── Service MethodChannel ──────────────────────────────
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, SERVICE_CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "startService" -> {
                        RemoteMonitorService.start(applicationContext)
                        result.success(null)
                    }
                    "stopService" -> {
                        RemoteMonitorService.stop(applicationContext)
                        result.success(null)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    // ── Helpers ───────────────────────────────────────────────

    /**
     * Checks whether RemoteAccessibilityService is listed as an enabled
     * accessibility service in the system settings.
     */
    private fun isAccessibilityServiceEnabled(): Boolean {
        val expectedComponentName =
            "${packageName}/${RemoteAccessibilityService::class.java.name}"
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabledServices)
        while (splitter.hasNext()) {
            if (splitter.next().equals(expectedComponentName, ignoreCase = true)) {
                return true
            }
        }
        return false
    }

    private fun notEnabledMsg() =
        "Accessibility Service is not enabled. Go to Settings → Accessibility → RemoteMonitor."
}
