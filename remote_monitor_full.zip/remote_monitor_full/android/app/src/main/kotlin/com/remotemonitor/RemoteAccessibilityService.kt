package com.remotemonitor

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.media.AudioManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.accessibility.AccessibilityEvent
import android.util.Log

/**
 * RemoteAccessibilityService
 *
 * Executes remote control actions sent from the controller device.
 * Flutter calls these via [MainActivity]'s MethodChannel.
 *
 * ──────────────────────────────────────────────────────────────
 * IMPORTANT: This service CANNOT be enabled programmatically.
 * The user must go to:
 *   Settings → Accessibility → Installed Services → RemoteMonitor → Enable
 * ──────────────────────────────────────────────────────────────
 *
 * A static [instance] is maintained so [MainActivity] can reach into
 * the running service without binding.
 */
class RemoteAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "RemoteAccessibility"

        /**
         * Singleton reference set when the service connects.
         * Null when the service is not enabled / not running.
         */
        @Volatile
        var instance: RemoteAccessibilityService? = null
            private set
    }

    // ── Lifecycle ─────────────────────────────────────────────

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "Accessibility service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // We do not need to inspect accessibility events for our use-case.
        // Keep this empty to avoid unnecessary processing.
    }

    override fun onInterrupt() {
        Log.w(TAG, "Accessibility service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        Log.i(TAG, "Accessibility service destroyed")
    }

    // ── Navigation actions ────────────────────────────────────

    /** Simulates pressing the system Back button. */
    fun performBack() {
        performGlobalAction(GLOBAL_ACTION_BACK)
        Log.d(TAG, "performBack")
    }

    /** Simulates pressing the Home button. */
    fun performHome() {
        performGlobalAction(GLOBAL_ACTION_HOME)
        Log.d(TAG, "performHome")
    }

    /** Opens the Recents / Overview screen. */
    fun performRecentApps() {
        performGlobalAction(GLOBAL_ACTION_RECENTS)
        Log.d(TAG, "performRecentApps")
    }

    // ── System actions ────────────────────────────────────────

    /**
     * Locks the screen.
     * Requires API 28+ for GLOBAL_ACTION_LOCK_SCREEN.
     * On older devices this is a no-op (would need DevicePolicyManager).
     */
    fun performLock() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
            Log.d(TAG, "performLock")
        } else {
            Log.w(TAG, "Lock requires API 28+")
        }
    }

    /**
     * Triggers a 300ms vibration pulse.
     * Uses the modern [VibrationEffect] API on API 26+ and falls back to
     * the deprecated [Vibrator.vibrate(long)] on older devices.
     */
    fun performVibrate() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator.vibrate(
                    VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                @Suppress("DEPRECATION")
                val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                v.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                @Suppress("DEPRECATION")
                v.vibrate(300)
            }
            Log.d(TAG, "performVibrate")
        } catch (e: Exception) {
            Log.e(TAG, "vibrate error: ${e.message}")
        }
    }

    /** Raises the media volume by one step and shows the UI. */
    fun performVolumeUp(context: Context) {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
        Log.d(TAG, "performVolumeUp")
    }

    /** Lowers the media volume by one step and shows the UI. */
    fun performVolumeDown(context: Context) {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        Log.d(TAG, "performVolumeDown")
    }

    /**
     * Takes a screenshot using the built-in global action.
     * Requires API 28+ (Android 9).
     */
    fun performScreenshot() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            Log.d(TAG, "performScreenshot")
        } else {
            Log.w(TAG, "Screenshot action requires API 28+")
        }
    }

    // ── Gesture actions ───────────────────────────────────────

    /**
     * Simulates a single tap at screen coordinates (x, y).
     * Uses [GestureDescription] which requires API 24+.
     *
     * @param x X coordinate in pixels (screen coordinates)
     * @param y Y coordinate in pixels (screen coordinates)
     */
    fun performTap(x: Float, y: Float) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val path = Path().apply { moveTo(x, y) }
            val stroke = GestureDescription.StrokeDescription(
                path,
                /* startTime= */ 0L,
                /* duration= */ 50L
            )
            val gesture = GestureDescription.Builder()
                .addStroke(stroke)
                .build()
            dispatchGesture(gesture, /* callback= */ null, /* handler= */ null)
            Log.d(TAG, "performTap x=$x y=$y")
        } else {
            Log.w(TAG, "Gesture dispatch requires API 24+")
        }
    }

    /**
     * Simulates a swipe from (startX, startY) to (endX, endY).
     *
     * @param durationMs Duration of the swipe in milliseconds
     */
    fun performSwipe(
        startX: Float, startY: Float,
        endX: Float, endY: Float,
        durationMs: Long = 300L
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val path = Path().apply {
                moveTo(startX, startY)
                lineTo(endX, endY)
            }
            val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            dispatchGesture(gesture, null, null)
            Log.d(TAG, "performSwipe ($startX,$startY)→($endX,$endY)")
        } else {
            Log.w(TAG, "Gesture dispatch requires API 24+")
        }
    }
}
