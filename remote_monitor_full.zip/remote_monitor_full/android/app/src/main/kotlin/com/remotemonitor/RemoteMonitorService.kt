package com.remotemonitor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat

/**
 * RemoteMonitorService
 *
 * A foreground [Service] that keeps the app process alive while a monitoring
 * session is active. Android requires foreground services to post a visible
 * notification — this is intentional so the monitored user is always aware.
 *
 * Start it via [start] and stop it via [stop] from Dart through the
 * SERVICE_CHANNEL MethodChannel in [MainActivity].
 */
class RemoteMonitorService : Service() {

    companion object {
        private const val TAG              = "RemoteMonitorService"
        const val CHANNEL_ID_SERVICE       = "rm_service_channel"
        const val CHANNEL_ID_ALERTS        = "rm_alerts_channel"
        const val NOTIFICATION_ID_SERVICE  = 1001
        private const val ACTION_STOP      = "com.remotemonitor.ACTION_STOP"

        /** Start the foreground service from any context. */
        fun start(context: Context) {
            val intent = Intent(context, RemoteMonitorService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            Log.i(TAG, "start() called")
        }

        /** Stop the foreground service from any context. */
        fun stop(context: Context) {
            context.stopService(Intent(context, RemoteMonitorService::class.java))
            Log.i(TAG, "stop() called")
        }
    }

    // ── Service lifecycle ──────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
        Log.i(TAG, "Service created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Handle stop action from notification button
        if (intent?.action == ACTION_STOP) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        // Start foreground with a visible notification
        startForeground(NOTIFICATION_ID_SERVICE, buildNotification())
        Log.i(TAG, "Service running in foreground")

        // Restart automatically if killed by the system
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "Service destroyed")
    }

    // Bound services not needed — return null
    override fun onBind(intent: Intent?): IBinder? = null

    // ── Notification ──────────────────────────────────────────

    private fun buildNotification(): Notification {
        // Tapping the notification opens MainActivity
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // "Disconnect" action button
        val stopIntent = Intent(this, RemoteMonitorService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID_SERVICE)
            .setContentTitle("RemoteMonitor")
            .setContentText("Monitoring session active")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(openPendingIntent)
            .setOngoing(true)             // Can't be swiped away
            .setSilent(true)              // No sound/vibration
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "Disconnect",
                stopPendingIntent
            )
            .build()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            // Persistent service channel — low importance, no sound
            val serviceChannel = NotificationChannel(
                CHANNEL_ID_SERVICE,
                getString(R.string.notification_channel_service_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_service_desc)
                setShowBadge(false)
                enableLights(false)
                enableVibration(false)
            }

            // Alerts channel — normal importance, for events
            val alertsChannel = NotificationChannel(
                CHANNEL_ID_ALERTS,
                getString(R.string.notification_channel_alerts_name),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = getString(R.string.notification_channel_alerts_desc)
                setShowBadge(true)
            }

            manager.createNotificationChannel(serviceChannel)
            manager.createNotificationChannel(alertsChannel)
            Log.d(TAG, "Notification channels created")
        }
    }
}
