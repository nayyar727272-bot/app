package com.remotemonitor

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log

/**
 * BootReceiver
 *
 * Listens for [Intent.ACTION_BOOT_COMPLETED] (and manufacturer variants)
 * so the foreground service can be restarted automatically after a reboot.
 *
 * Declared in AndroidManifest.xml with the RECEIVE_BOOT_COMPLETED permission.
 *
 * NOTE: On Android 10+ (API 29+) you cannot start an Activity from
 * a background broadcast. We start the foreground Service instead,
 * which shows a notification and then optionally opens MainActivity.
 */
class BootReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "BootReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return

        val isBoot = action == Intent.ACTION_BOOT_COMPLETED
                || action == "android.intent.action.QUICKBOOT_POWERON"
                || action == "com.htc.intent.action.QUICKBOOT_POWERON"

        if (!isBoot) return

        Log.i(TAG, "Boot completed — starting RemoteMonitorService")

        // Check SharedPreferences to see if a session was active before reboot
        val prefs = context.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
        val setupComplete = prefs.getBoolean("flutter.setup_complete", false)

        if (!setupComplete) {
            Log.d(TAG, "Setup not complete — skipping auto-start")
            return
        }

        // Start the foreground service — it will show a notification
        RemoteMonitorService.start(context)
    }
}
